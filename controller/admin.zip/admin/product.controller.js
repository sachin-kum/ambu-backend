const productModel = require('../../model/product/product')

exports.get_all_product = async (req, res) => {
    try { 
        const find = await productModel.find().sort({creatdAt:-1})

        res.render('pages/product/view_products',{
            data:find
        })
     
    } catch (error) {
        console.log(error);
        res.status(500).json({ message: error.message, status: false })
    }
}
const category = require("../../model/category/category.model")


exports.get_all_category = async (req, res) => {
    try {
        const find_data=await category.find().sort({creatdAt:-1})

        res.render('pages/category/category',{
            data:find_data
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({ message: error.message, status: false })
    }
}